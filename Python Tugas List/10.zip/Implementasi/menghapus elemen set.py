#remove
A = {1,2,3,4,5}
A.remove(3)
print(A)

#discard
A = {1,2,3,4,5}
A.discard(3)
print(A)