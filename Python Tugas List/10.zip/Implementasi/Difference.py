A = {1,2,3,4,5}
B = {4,5,6,7,8}
#A.difference(B) atau juga bisa
C = A - B
print(C)