A = {1,2,3,4,5}
B = {6,7,8,9,10}
C = A.union(B)
print(C)
