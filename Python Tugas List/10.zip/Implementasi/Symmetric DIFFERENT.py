A = {1,2,3,4,5}
B = {4,5,6,7,8}
#A.symmetric_difference(B) atau bisa pake
C = A ^ B
print(C)