A = {1,2,3,4,5}
B = {5,6,7,8,9}
C = A.intersection(B)
print(C)