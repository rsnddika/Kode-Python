a = {"keju", "tepung", "garam", "gula", "coklat"}
b = {"garam", "gula", "coklat", "kecap"}
b.add("keju")

a.discard("garam")

#barang yang dibeli di hari kedua
print("Keperluan rumah tangga yang dibeli dihari kedua :",b)