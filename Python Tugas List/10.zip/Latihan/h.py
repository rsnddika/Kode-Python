a = {"keju", "tepung", "garam", "gula", "coklat"}
b = {"garam", "gula", "coklat", "kecap"}
b.add("keju")

a.discard("garam")

#barang yang dibeli di hari pertama
print("Keperluan rumah tangga yang dibeli dihari pertama :", a)