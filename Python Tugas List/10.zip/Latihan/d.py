a = {"keju", "tepung", "garam", "gula", "coklat"}
b = {"garam", "gula", "coklat", "kecap"}
b.add("keju")

#d = barang yang di a tpi tidak ada di barang b(difference)
d = a - b
print(d)