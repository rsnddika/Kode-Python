#pembelian hari pertama = a
#pembelian hari kedua = b
a = {"keju", "tepung", "garam", "gula", "coklat"}
b = {"garam", "gula", "coklat", "kecap"}
print(a)
print(b)